package app.model;

import javax.persistence.Entity;

@Entity
public class Publisher extends User {
}
