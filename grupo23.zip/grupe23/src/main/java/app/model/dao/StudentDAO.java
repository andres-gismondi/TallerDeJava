package app.model.dao;


import app.model.Student;

public interface StudentDAO extends GenericDAO<Student>{
    /*
    public void suscribeBillboard(BillboardDAO billboard){}

    public void orderBillboard(BillboardDAO billboard){}
*/
}
