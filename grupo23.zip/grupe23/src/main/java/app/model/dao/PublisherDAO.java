package app.model.dao;

import app.model.Publisher;

public interface PublisherDAO extends GenericDAO<Publisher>{
    /*
    public void enableCommentaries(){}

    public void disableCommentaries(){}
    */

}
