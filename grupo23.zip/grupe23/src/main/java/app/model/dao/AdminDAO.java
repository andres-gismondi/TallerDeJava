package app.model.dao;


import app.model.Admin;

public interface AdminDAO extends GenericDAO<Admin>{

    /*
    public void addBillboard(){}

    public void addUser(){}

    public void addPublication(BillboardDAO billboard, PublicationDAO publication){}

    public void deleteBillboard(BillboardDAO billboard){}

    public void deleteUser(UserDAO user){};

    public void deletePublication(BillboardDAO billboard, PublicationDAO publication){}

    public void modifyBillboard(BillboardDAO billboard){}

    public void modifyUser(UserDAO user){}

    public void modifyPublication(PublicationDAO publication){}

    public void enableCommentary(CommentaryDAO commentary){}

    public void enablePublicationCommentary(PublicationDAO publication){}

    public void modifyUserCategory(CategoryDAO category, UserDAO user){}

    public void deleteCategory(CategoryDAO category){}

    public void modifyCategory(CategoryDAO category){}

    public void addCategory(CategoryDAO category){}

    public void orderBillboard(BillboardDAO billboard){}
    */
}
