package app.model.dao;

import app.model.Teacher;

public interface TeacherDAO extends GenericDAO<Teacher>{
    /*
    public void addPublication(BillboardDAO billboard, PublicationDAO publication){}

    public void deletePublication(BillboardDAO billboard, PublicationDAO publication){}

    public void modifyPublication(PublicationDAO publication){}

    public void enableCommentary(CommentaryDAO commentary){}

    public void enablePublicationCommentary(PublicationDAO publication){}

    public List<StudentDAO> interestedStudents(BillboardDAO billboard){ return null; }

    public void orderBillboard(BillboardDAO billboard){}
    */
}
