package app.model;

import javax.persistence.Entity;

@Entity
public class Teacher extends User {
}
