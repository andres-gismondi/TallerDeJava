package app.model;

import javax.persistence.Entity;

@Entity
public class Student extends User {
}
